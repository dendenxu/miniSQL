# !usr/bin/python

import sys
sys.path.append("code")
from GUI import main
main()